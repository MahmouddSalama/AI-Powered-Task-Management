package com.example.ai_task_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
