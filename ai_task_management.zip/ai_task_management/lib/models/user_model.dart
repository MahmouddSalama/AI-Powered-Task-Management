class UserModel {
  final String name;
  final String email;
  final String pass;
  final String phone;
  final String id;


  UserModel({
    required this.name,
    required this.email,
    required this.pass,
    required this.phone,
    required this.id,
  });

  factory UserModel.fromjson(jsonData) {
    return UserModel(
      name:jsonData['name'] ,
      email: jsonData['email'],
      pass: jsonData['password'],
      phone: jsonData['phone'],
      id: jsonData['id'],
    );
  }
}
