class Task {
  String id;
  String title;
  String category;
  String note;
  DateTime deadline;
  int priority;
  bool isCompleted;

  Task({
    required this.id,
    required this.title,
    required this.category,
    required this.note,
    required this.deadline,
    required this.priority,
    this.isCompleted = false,
  });

  // Convert Task to Map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'category': category,
      'note': note,
      'deadline': deadline.toIso8601String(),
      'priority': priority,
      'isCompleted': isCompleted,
    };
  }

  // Create Task from Firestore Map
  factory Task.fromMap(Map<String, dynamic> map, String docId) {
    return Task(
      id: docId,
      title: map['title'] ?? '',
      category: map['category'] ?? '',
      note: map['note'] ?? '',
      deadline: DateTime.parse(map['deadline']),
      priority: map['priority'] ?? 0,
      isCompleted: map['isCompleted'] ?? false,
    );
  }

  // CopyWith method
  Task copyWith({
    String? id,
    String? title,
    String? category,
    String? note,
    DateTime? deadline,
    int? priority,
    bool? isCompleted,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      note: note ?? this.note,
      deadline: deadline ?? this.deadline,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}
