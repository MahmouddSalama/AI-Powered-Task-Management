// import 'package:flutter/material.dart';
//
// import '../consts_statics/colors.dart';
// import '../functions/get_size.dart';
// class DropWidget extends StatelessWidget {
//   const DropWidget({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: GetSize.getWidth(context) * .96,
//       height: 70,
//       decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(6),
//           border: Border.all(color: KButtonColor)),
//       child: Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: DropdownButton<String>(
//           value: dropdownValue,
//           icon: Icon(
//             Icons.arrow_downward,
//             color: KButtonColor,
//           ),
//           elevation: 16,
//           style: const TextStyle(color: Colors.black),
//           onChanged: (String? value) {
//             // This is called when the user selects an item.
//             setState(() {
//               dropdownValue = value!;
//             });
//           },
//           items:
//           list.map<DropdownMenuItem<String>>((String value) {
//             return DropdownMenuItem<String>(
//               value: value,
//               child: Text(value),
//             );
//           }).toList(),
//         ),
//       ),
//     );
//   }
// }
