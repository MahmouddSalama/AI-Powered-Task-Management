
import 'package:flutter/material.dart';

import '../consts_statics/colors.dart';


class AddButton extends StatelessWidget {
  final IconData? iconData;
  final Function function;
  final String? string;
  final Color color;


  const AddButton({Key? key, this.iconData,required this.function,this.string,this.color=KprimaryColor}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ()=>function(),
      child: Container(
        width: 55,
        height: 55,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child:string==null? Icon(
          iconData,
          color: Colors.white,
        ):Text('$string',style: TextStyle(
            color: Colors.white,
            fontSize: 18
        ),),
      ),
    );
  }
}
