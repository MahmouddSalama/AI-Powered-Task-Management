import 'package:flutter/material.dart';

import '../consts_statics/colors.dart';


class CustomButton extends StatelessWidget {
   CustomButton({
    required this.function,
     required this.text,
     this.color = KprimaryColor,
    super.key,
  });

  VoidCallback function;
  String text;
  Color? color = KButtonColor;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: function,
      child: Container(
        width: 250,
        height: 60,
        decoration: BoxDecoration(
            color: color!,
            borderRadius: BorderRadius.circular(9)
        ),
        child:  Center(child: Text(text,style: const TextStyle(
          color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 21,
          fontFamily: "Pacifico"
        ),)),
      ),
    );
  }
}