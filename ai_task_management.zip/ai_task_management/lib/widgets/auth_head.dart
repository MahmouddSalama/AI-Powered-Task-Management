

import 'package:flutter/material.dart';

import '../consts_statics/colors.dart';

class AuthHead extends StatelessWidget {
  AuthHead({super.key,required this.name});
  String name;
  @override
  Widget build(BuildContext context) {
    return  Column(
      children: [
        const SizedBox(
          height: 75,
        ),
        Image.asset(
          "assets/images/logo.png",
          height: 200,
        ),
        const Align(
          alignment: Alignment.center,
          child: Text(
            "AI Task Management",
            style: TextStyle(
                fontSize: 30, fontFamily: "Pacifico", color: KprimaryColor),
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            name,
            style: const TextStyle(fontSize: 18, color: Colors.white),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}