
import 'package:flutter/material.dart';

import '../consts_statics/colors.dart';

import '../screens/shared_screens/profile_screen.dart';
import 'auth_head.dart';
import 'drawer_tile.dart';

class AdminDrawer extends StatelessWidget {
  final String name;
  AdminDrawer({
    required this.name,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: KprimaryColor,
      child: Column(
        children: [
          AuthHead(name: ""),
          Divider(color: Colors.white70),
          DrawerTile(
              text: 'Profile',
              iconData: Icons.person,
              function: () {
                Navigator.push(context, MaterialPageRoute(builder: (context){
                  return ProfileScreen(name: name,);
                }));
                // },
              }
          ),
          DrawerTile(
            text:'Manage Users',
            iconData: Icons.settings,
            function: (){
             /* Navigator.push(context, MaterialPageRoute(builder: (context){
                return ManageUsers();
              }));*/
            },
          ),




          Spacer(flex: 3),
          DrawerTile(
            text: 'LogOut',
            iconData: Icons.logout,
            function: (){
              // LogOut from firebase
             // Auth.logOut(context);

            },
          ),
          Spacer(flex: 1),
        ],
      ),
    );
  }
}