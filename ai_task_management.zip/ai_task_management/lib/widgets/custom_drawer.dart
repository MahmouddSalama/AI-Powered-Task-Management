import 'package:ai_task_management/screens/ai_screens/ai_screen.dart';
import 'package:ai_task_management/screens/user_screens/add_task_screen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../screens/shared_screens/profile_screen.dart';
import '../services/auth_services.dart';
import 'auth_head.dart';
import 'drawer_tile.dart';

class CustomDrawer extends StatefulWidget {
  final String name;
  CustomDrawer({
    required this.name,
    super.key,
  });

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {

  String? userType = null;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }



  @override
  Widget build(BuildContext context) {


    return Drawer(
      //backgroundColor: KprimaryColor,
      child: Column(
        children: [
          AuthHead(name: ""),
          Divider(color: Colors.white70),
          DrawerTile(
            text: 'Profile',
            iconData: Icons.person,
            function: () {
                Navigator.push(context, MaterialPageRoute(builder: (context){
                  return ProfileScreen(name: widget.name,);
                }));
              // },
            }
          ),
          DrawerTile(
            text:'Home',
            iconData: Icons.home,
            function: (){
              Navigator.pop(context );
            },
          ),
          DrawerTile(
              text: 'Ai Services',
              iconData: FontAwesomeIcons.robot,
              function: () {
                Navigator.push(context, MaterialPageRoute(builder: (context){
                  return AiScreen();
                }));
                // },
              }
          ),
          Spacer(flex: 3),
          DrawerTile(
            text: 'LogOut',
            iconData: Icons.logout,
            function: (){
              // LogOut from firebase
             Auth.logOut(context);
            },
          ),
          Spacer(flex: 1),
        ],
      ),
    );
  }
}