import 'package:ai_task_management/consts_statics/colors.dart';
import 'package:ai_task_management/screens/user_screens/add_task_screen.dart';
import 'package:ai_task_management/services/task_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/task_model.dart';

class TaskCard extends StatefulWidget {
  final Task task;

   TaskCard({super.key, required this.task});

  @override
  State<TaskCard> createState() => _TaskCardState();
}

class _TaskCardState extends State<TaskCard> {
  final User? auth = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    final daysLeft = widget.task.deadline.difference(DateTime.now()).inDays;
    final houres = widget.task.deadline.difference(DateTime.now()).inHours;
    final priorityColors = [Colors.green, Colors.orange, Colors.red];
    final priorityLevel = widget.task.priority.clamp(0, 2);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              PopupMenuButton<String>(
                onSelected: (String value) {
                  if(value=='done!'){
                   Task newTask=widget.task.copyWith(isCompleted: true);
                   setState(() {});
                   TaskServices().updateTask(newTask,auth!.uid);
                  }
                 else if(value=='in progress'){
                    Task newTask=widget.task.copyWith(isCompleted: false);
                    setState(() {});
                    TaskServices().updateTask(newTask,auth!.uid);
                  }
                    else if  (value == 'edit') {
                    Navigator.push(context, MaterialPageRoute(builder: (context){
                      return AddTaskScreen(task: widget.task,);
                    }));
                  } else if (value == 'delete') {
                    TaskServices().deleteTask(widget.task.id,auth!.uid);
                  }
                },
                itemBuilder: (BuildContext context) => [
                  const PopupMenuItem<String>(
                    value: 'edit',
                    child: ListTile(
                      leading: Icon(Icons.edit),
                      title: Text('Edit Task'),
                    ),
                  ),
                  const PopupMenuItem<String>(
                    value: 'delete',
                    child: ListTile(
                      leading: Icon(Icons.delete),
                      title: Text('Delete Task'),
                    ),
                  ),
                   PopupMenuItem<String>(
                    value: widget.task.isCompleted ? 'in progress' :'done!',
                    child: ListTile(
                      leading: Icon( widget.task.isCompleted ?Icons.done:Icons.done_all_rounded,color: KprimaryColor,),
                      title: Text( widget.task.isCompleted? 'Task In Progress':'Task Done'),
                    ),
                  ),
                ],
                icon: const Icon(Icons.more_vert),
              ),
              Expanded(
                child: Text(widget.task.title,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              Text(
                DateFormat('EEE, MMM d').format(widget.task.deadline),
                style: const TextStyle(color: Colors.grey),
              )
            ],
          ),
          const SizedBox(height: 6),
          Text("Category - ${widget.task.category}",
              style: const TextStyle(color: Colors.blueGrey, fontSize: 13)),
          const SizedBox(height: 10),

          if (widget.task.note.isNotEmpty)
            Text(
              widget.task.note,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.black87),
            ),

          const SizedBox(height: 16),

          // Status & Priority
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Chip(
                label: Text(widget.task.isCompleted ? "Completed" : "In Progress"),
                backgroundColor:
                widget.task.isCompleted ? Colors.green[100] : Colors.green,
                labelStyle: TextStyle(
                    color: widget.task.isCompleted ? Colors.green :KprimaryColor),
              ),
              Row(
                children: [
                  const Icon(Icons.flag, size: 16, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                    ["Low", "Medium", "High"][priorityLevel],
                    style: TextStyle(
                        color: priorityColors[priorityLevel],
                        fontWeight: FontWeight.w500),
                  ),
                ],
              )
            ],
          ),

          const SizedBox(height: 10),

          // Days left
          Row(
            children: [


              Spacer(),
              Align(
                alignment: Alignment.centerRight,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      daysLeft >= 0
                          ? "$daysLeft day${daysLeft == 1 ? '' : 's'} left"
                          : "Overdue by ${-daysLeft} day${daysLeft == -1 ? '' : 's'}",
                      style: TextStyle(
                          color: daysLeft >= 0 ? Colors.blueGrey : Colors.red,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                    ),
                    Text(
                      daysLeft == 0
                          ? '${houres} hours left'
                          : '',
                      style: TextStyle(
                          color: daysLeft >= 0 ? Colors.blueGrey : Colors.red,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
