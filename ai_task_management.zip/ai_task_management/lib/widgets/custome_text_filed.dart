

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../consts_statics/colors.dart';


class CustumeTextField extends StatefulWidget {

  CustumeTextField({this.maxline,this.textEditingController,this.hint,this.onchange,required  this.validetor,required this.ispass,this.labelText,this.keyboardType=TextInputType.text,this.enabled});
  String? hint;
  bool? enabled;
  String? labelText;
  TextInputType keyboardType=TextInputType.text;
  Function(String)? onchange;
  final String? Function(dynamic value) validetor;
   bool? ispass;
   bool visibility=true;
  TextEditingController? textEditingController;
  int? maxline;
  @override
  State<CustumeTextField> createState() => _CustumeTextFieldState();
}

class _CustumeTextFieldState extends State<CustumeTextField> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        height: 60,
        child: TextFormField(

          obscureText: widget.ispass!,
          enabled: widget.enabled,
          maxLines:widget.ispass!?1: widget.maxline,
          keyboardType: widget.keyboardType,
          style: TextStyle(
            color: Colors.black
          ),
            validator: (v) => widget.validetor(v),
          onChanged:widget.onchange ,
          controller: widget.textEditingController,
          decoration: InputDecoration(
              hintText: widget.hint,
              labelText: widget.labelText,
              labelStyle: TextStyle(
                  color: Colors.black
              ),
              hintStyle: TextStyle(
                  color: Colors.black45
              ),
              border: OutlineInputBorder(
                borderSide: BorderSide(
                  width: 1,
                    color: KButtonColor
                ),
                borderRadius: BorderRadius.circular(6),
              ),
              disabledBorder:OutlineInputBorder(
                borderSide: BorderSide(
                    width: 1,
                    color:KButtonColor
                ),
                borderRadius: BorderRadius.circular(6),
              ) ,
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    width: 1,
                    color:KButtonColor
                ),
                borderRadius: BorderRadius.circular(6),
              ),
            errorBorder: OutlineInputBorder(

              borderRadius: BorderRadius.circular(6),
              borderSide: BorderSide(
                style: BorderStyle.solid,
                color: Colors.red,
              )
            ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    width: 2,
                    color:KButtonColor
                ),
                borderRadius: BorderRadius.circular(6),
          )
          ),
        ),
      ),
    );
  }
}