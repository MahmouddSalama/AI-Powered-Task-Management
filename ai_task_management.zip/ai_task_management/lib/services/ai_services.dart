import 'dart:convert';
import 'package:http/http.dart' as http;

class AiServices {
  static const String _baseUrl = 'http://192.168.1.5:8000';

  static Future<String?> getRecommendedTask(Map<String, dynamic> formData) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/task_recommendation'),
        headers: {"Content-Type": "application/json"},
        body: json.encode(formData),
      );

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        return result["recommended_task"];
      } else {
        throw Exception("Server error: ${response.body}");
      }
    } catch (e) {
      throw Exception("Failed to get recommendation: $e");
    }
  }
}
