import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/task_model.dart';


class TaskServices {
  final CollectionReference _taskCollection =
  FirebaseFirestore.instance.collection('tasks');

  Future<void> addTask(Task task,String uid) async {
    try {
      DocumentReference docRef = _taskCollection.doc(uid).collection('user-Task').doc();
      Task newTask = task.copyWith(id: docRef.id);
      await docRef.set(newTask.toMap());
    } catch (e) {
      throw Exception('Failed to add task: $e');
    }
  }
  Future<void> updateTask(Task task,String uid) async {
    try {
      await _taskCollection.doc(uid).collection('user-Task').doc(task.id).update(task.toMap());
    } catch (e) {
      throw Exception('Failed to update task: $e');
    }
  }
  Future<void> deleteTask(String taskId,String uid) async {
    try {
      await _taskCollection.doc(uid).collection('user-Task').doc(taskId).delete();
    } catch (e) {
      throw Exception('Failed to delete task: $e');
    }
  }
  Stream<List<Task>> getTasksStream(String uid) {
    return _taskCollection.doc(uid).collection('user-Task')
        .orderBy('deadline')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Task.fromMap(doc.data() as Map<String, dynamic>, doc.id);
      }).toList();
    });
  }

  Future<Task?> getTaskById(String taskId,String uid) async {
    try {
      DocumentSnapshot doc = await _taskCollection.doc(uid).collection('user-Task').doc(taskId).get();
      if (doc.exists) {
        return Task.fromMap(doc.data() as Map<String, dynamic>, doc.id);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to fetch task: $e');
    }
  }
}
