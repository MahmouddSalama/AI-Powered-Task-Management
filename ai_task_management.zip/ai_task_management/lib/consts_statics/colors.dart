import 'package:flutter/material.dart';

const Color KprimaryColor=Color(0xff002267);//Color(0xff3AC4A0);
Color KButtonColor=Color(0xff002267);
