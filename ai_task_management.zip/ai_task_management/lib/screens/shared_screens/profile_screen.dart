import 'package:ai_task_management/services/auth_services.dart';
import 'package:ai_task_management/widgets/custome_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../consts_statics/colors.dart';
import '../../models/user_model.dart';

class ProfileScreen extends StatefulWidget {
  ProfileScreen({super.key, required this.name});

  final String name;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool lang = true;

  UserModel userModel = UserModel(
      name: 'John wike',
      email: 'john.wike@gmail.com',
      pass: "*******",
      phone: '0123456789',
      id: 'id',
     );

  @override
  Widget build(BuildContext context) {
    final User? auth = FirebaseAuth.instance.currentUser;
    CollectionReference<Map<String, dynamic>> data =
    FirebaseFirestore.instance.collection('Users');
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.white
        ),
        backgroundColor: KprimaryColor,
        elevation: 0,
        centerTitle: true,
        title: Text(
          "Actor Info",
          style: TextStyle(
              fontSize: 22, fontFamily: "Pacifico", color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: SingleChildScrollView(
          child: StreamBuilder<QuerySnapshot>(
              stream: data.where('id', isEqualTo: auth!.uid).snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  UserModel userModel =
                  UserModel.fromjson(snapshot.data!.docs[0]);
                  return Column(
                    children: [
                      SizedBox(height: 50),
                      CircleAvatar(
                        
                        radius: 80,
                        child: Image.asset(
                          "assets/images/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Text(
                        "Name : ${userModel.name}",
                        style: TextStyle(fontSize: 18),
                      ),
                      SizedBox(
                        height: 10,
                      ),

                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'INFO',
                          style: TextStyle(
                              color: KprimaryColor,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Divider(
                        color: KprimaryColor,
                        thickness: 1.2,
                      ),
                      buildColumn(
                          text: "Name : ${userModel.name}", icon: Icons.person),
                      buildColumn(
                          text: "Email : ${userModel.email}", icon: Icons.email),

                      buildColumn(
                          text: "Phone : ${userModel.phone}", icon: Icons.code),
                      SizedBox(height: 20),
                      CustomButton(function: ()async{
                       await Auth.logOut(context);
                      }, text: 'Logout')
                    ],
                  );
                }
                else{
                  return Center(child: CircularProgressIndicator(color: Colors.black,),);
                }
              }),
        ),
      ),
    );
  }

  Column buildColumn({text, icon}) {
    return Column(
      children: [
        ListTile(
          title: Text(text),
          leading: Icon(
            icon,
            color: KprimaryColor,
          ),
        ),
        Divider(
          color: KprimaryColor,
          thickness: 1.2,
        )
      ],
    );
  }
}
