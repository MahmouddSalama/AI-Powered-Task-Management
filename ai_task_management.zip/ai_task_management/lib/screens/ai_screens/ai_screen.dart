import 'package:flutter/material.dart';

import '../../consts_statics/colors.dart';
import '../../services/ai_services.dart';

class AiScreen extends StatefulWidget {
  @override
  _TaskRecommendationScreenState createState() => _TaskRecommendationScreenState();
}

class _TaskRecommendationScreenState extends State<AiScreen> {
  final _formKey = GlobalKey<FormState>();
  final _taskTypeController = TextEditingController();
  final _fieldController = TextEditingController();
  final _difficultyController = TextEditingController();
  final _currentSkillsController = TextEditingController();
  final _skillsToLearnController = TextEditingController();
  final _availableTimeController = TextEditingController();

  String? recommendedTask;
  bool isLoading = false;
// Add at the top of _TaskRecommendationScreenState
  List<String> _difficultyOptions = ['Easy', 'Medium', 'Hard'];
  String? _selectedDifficulty;

  List<String> currentSkills = [];
  List<String> skillsToLearn = [];

  final TextEditingController _currentSkillInput = TextEditingController();
  final TextEditingController _skillToLearnInput = TextEditingController();

  Future<void> _submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      setState(() {
        isLoading = true;
        recommendedTask = null;
      });

      final formData = {
        "Task Type": _taskTypeController.text,
        "Field": _fieldController.text,
        "Difficulty": _selectedDifficulty ?? '',
        "Current Skills": currentSkills.join(', '),
        "Skills to Learn": skillsToLearn.join(', '),
        "Available Time per Day (hrs)": int.parse(_availableTimeController.text),
      };

      try {
        final task = await AiServices.getRecommendedTask(formData);
        setState(() {
          recommendedTask = task;
        });
      } catch (e) {
        setState(() {
          recommendedTask = "Error: ${e.toString()}";
        });
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Widget _buildTextField(String label, TextEditingController controller, {TextInputType inputType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: TextFormField(
        controller: controller,
        keyboardType: inputType,
        validator: (value) => value == null || value.isEmpty ? 'Required' : null,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
            color: Colors.white
        ),
        title: Text('Ai Services',style: TextStyle(
            color: Colors.white,
            fontFamily: 'Pacifico'
        ),),
        centerTitle: true,
        backgroundColor: KprimaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                _buildTextField("Task Type", _taskTypeController),
                _buildTextField("Field", _fieldController),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: "Difficulty",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    value: _selectedDifficulty,
                    items: _difficultyOptions
                        .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                        .toList(),
                    validator: (value) => value == null ? 'Required' : null,
                    onChanged: (value) => setState(() => _selectedDifficulty = value),
                  ),
                ),
                _buildSkillInput(
                  label: "Current Skills",
                  skillList: currentSkills,
                  inputController: _currentSkillInput,
                ),
                _buildSkillInput(
                  label: "Skills to Learn",
                  skillList: skillsToLearn,
                  inputController: _skillToLearnInput,
                ),
                _buildTextField("Available Time per Day (hrs)", _availableTimeController, inputType: TextInputType.number),

                SizedBox(height: 20),
                ElevatedButton(

                  onPressed: isLoading ? null : _submitForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: KprimaryColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  ),
                  child: isLoading
                      ? CircularProgressIndicator(color: Colors.purple)
                      : Text("Get Recommendation",style: TextStyle(
                    color: Colors.white
                  ),),
                ),
                SizedBox(height: 20),

                if (recommendedTask != null)
                  Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    elevation: 8,
                    color: Colors.teal.shade50,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          Text("Recommended Task", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          SizedBox(height: 10),
                          Text(
                            recommendedTask!,
                            style: TextStyle(fontSize: 16, color: Colors.teal[900]),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSkillInput({
    required String label,
    required List<String> skillList,
    required TextEditingController inputController,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontWeight: FontWeight.bold)),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: inputController,
                  decoration: InputDecoration(
                    hintText: "Enter skill",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                ),
              ),
              IconButton(
                icon: Icon(Icons.add_circle, color: KprimaryColor),
                onPressed: () {
                  final skill = inputController.text.trim();
                  if (skill.isNotEmpty) {
                    setState(() {
                      skillList.add(skill);
                      inputController.clear();
                    });
                  }
                },
              ),
            ],
          ),
          Wrap(
            spacing: 8,
            children: skillList.map((skill) {
              return Chip(
                label: Text(skill),
                deleteIcon: Icon(Icons.close),
                onDeleted: () {
                  setState(() => skillList.remove(skill));
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

}
