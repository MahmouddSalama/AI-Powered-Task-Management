import 'package:flutter/material.dart';
import '../../consts_statics/colors.dart';
import '../../functions/get_size.dart';
import '../../widgets/custome_button.dart';
import '../auth_screens/login.dart';



class SplashScreen extends StatefulWidget {
   SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool isstart=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Image.asset(
              "assets/images/logo.png",
              height: 300,
              width: GetSize.getWidth(context),
              fit: BoxFit.fitWidth,
            ),
             Text(
             'AI Task Management',
              style: TextStyle(
                  fontSize: 32, fontFamily: "Pacifico", color: KprimaryColor),
            ),
            const SizedBox(height: 50,),
            isstart? Container(
              width: 100,
              height: 100,
              child: CircularProgressIndicator(color: KprimaryColor,),
            ): CustomButton(
              color: KprimaryColor,
              text: 'Get Started',
              function: (){
                isstart=true;
                setState(() {});
                Future.delayed(Duration(seconds: 2),() {
                  isstart=false;
                  setState(() {});
                },).then((value) {
                  Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) {
                    return LoginPage();
                  }));
                });
              },
            )
          ],
        ),
      ),
    );
  }
}


