
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';




import '../../consts_statics/colors.dart';

import '../../services/auth_services.dart';
import '../../widgets/auth_head.dart';
import '../../widgets/custome_button.dart';
import '../../widgets/custome_text_filed.dart';
import '../../widgets/register_row.dart';
import 'register.dart';
import 'reset_password.dart';


class LoginPage extends StatefulWidget {
  LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    emailController.dispose();
    passController.dispose();
  }

  String? email, password;
  bool isloading=false;
  GlobalKey<FormState> formKey=GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: ModalProgressHUD(
          inAsyncCall: isloading,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  AuthHead(name: "LOGIN"),
                  CustumeTextField(
                    labelText: 'Email',
                    textEditingController: emailController,
                    ispass: false,
                    validetor: (value) {
                      if (value.isEmpty) {
                        return 'Please enter an email address';
                      }
                      if (!RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$')
                          .hasMatch(value)) {
                        return 'Please enter a valid email address';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      email = data;
                      setState(() {});
                    },
                    hint: "email.email@gmail.com",
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CustumeTextField(
                    labelText: 'Password',
                    textEditingController: passController,
                    validetor: (data) {
                      if (data.isEmpty) {
                        return 'Please enter a password';
                      }
                      // Simple password length check
                      if (data.length < 8) {
                        return 'Password must be at least 8 characters long';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      password = data;
                      setState(() {});
                    },
                    hint: "*********",
                    ispass: true,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) {
                            return ResetPassword();
                          }));
                    },
                    child: Text(
                      "Reset Password",
                      style:  TextStyle(
                        color: KButtonColor,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CustomButton(
                    color: KprimaryColor,
                      text: 'Login',
                      function: ()  {
                        login();

                      }),
                  const SizedBox(
                    height: 20,
                  ),
                  RegisterRow(text: "Actor", screen:RegisterPage() )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  void login() async{
    print("login");
    if (formKey.currentState!.validate()){
      isloading = true;
      setState(() {});
      // Navigator.push(context, MaterialPageRoute(builder: (context){
      //   return AdminHome();
      // }));
       await Auth.login(email: emailController.text, pass: passController.text, ctx: context);
      isloading = false;
      setState(() {});
    }
  }
}


