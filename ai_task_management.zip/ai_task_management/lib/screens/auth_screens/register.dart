import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../../consts_statics/colors.dart';
import '../../functions/get_size.dart';

import '../../models/user_model.dart';
import '../../services/auth_services.dart';
import '../../widgets/auth_head.dart';
import '../../widgets/custome_button.dart';
import '../../widgets/custome_text_filed.dart';
import 'login.dart';

class RegisterPage extends StatefulWidget {
  RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  List<String> list = <String>['Pet Owner', 'Pet Finder'];
  String dropdownValue = 'Pet Owner';

  String? email;
  String? name;
  String? password;
  String? phone;
  bool islodaing = false;

  GlobalKey<FormState> formKey = GlobalKey();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    nameController.dispose();
    emailController.dispose();
    passController.dispose();
    phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: ModalProgressHUD(
          inAsyncCall: islodaing,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  AuthHead(name: "Register"),
                  CustumeTextField(
                    labelText: 'Email',
                    keyboardType: TextInputType.emailAddress,
                    textEditingController: emailController,
                    ispass: false,
                    validetor: (value) {
                      if (value.isEmpty) {
                        return 'Please enter an email address';
                      }
                      if (!RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$')
                          .hasMatch(value)) {
                        return 'Please enter a valid email address';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      name = data;
                      setState(() {});
                    },
                    hint: "John.Smith@gmail.com",
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustumeTextField(
                    textEditingController: nameController,
                    labelText: 'Name',
                    ispass: false,
                    validetor: (value) {
                      if (value.isEmpty) {
                        return 'Please enter your name';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      name = data;
                      setState(() {});
                    },
                    hint: "John Smith",
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustumeTextField(
                    textEditingController: phoneController,
                    labelText: "Phone",
                    keyboardType: TextInputType.phone,
                    ispass: false,
                    validetor: (value) {
                      if (value.isEmpty) {
                        return 'Please enter an Phone';
                      }
                      if (value.isEmpty) {
                        return 'Enter valid phone';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      email = data;
                      setState(() {});
                    },

                    hint: "01123456789",
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustumeTextField(
                    textEditingController: passController,
                    labelText: "Password",
                    validetor: (data) {
                      if (data.isEmpty) {
                        return 'Please enter a password';
                      }
                      // Simple password length check
                      if (data.length < 8) {
                        return 'Password must be at least 8 characters long';
                      }
                      return null; // Validation passed
                    },
                    onchange: (data) {
                      password = data;
                      setState(() {});
                    },
                    hint: "*********",
                    ispass: true,
                  ),
                  const SizedBox(
                    height: 20,
                  ),

                  SizedBox(
                    height: 20,
                  ),

                  CustomButton(
                    text: "Register",
                    function: () async {
                      UserModel user = UserModel(
                        name: nameController.text,
                        email: emailController.text,
                        pass: passController.text,
                        phone: phoneController.text,
                        id: "id",
                      );

                      register(userModel: user);
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "do have an account ?",
                        style: TextStyle(
                          color:KprimaryColor,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) {
                            return LoginPage();
                          }));
                        },
                        child:  Text(
                          "  Login",
                          style: TextStyle(
                            color: KButtonColor,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void register({required UserModel userModel}) async {
    if (formKey.currentState!.validate()) {
      islodaing = true;
      setState(() {});
      await Auth.register(userModel: userModel, ctx: context);

      islodaing = false;
      setState(() {});
    }

  }
}
