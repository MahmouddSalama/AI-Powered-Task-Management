import 'package:ai_task_management/consts_statics/colors.dart';
import 'package:ai_task_management/models/task_model.dart';
import 'package:ai_task_management/services/task_services.dart';
import 'package:ai_task_management/widgets/custom_drawer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../widgets/task_card.dart';
import 'add_task_screen.dart';
class UserHome extends StatelessWidget {
   UserHome({super.key});
  final User? auth = FirebaseAuth.instance.currentUser;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.white
        ),
        title: Text('Tasks',style: TextStyle(
          color: Colors.white,
          fontFamily: 'Pacifico'
        ),),
        centerTitle: true,
        backgroundColor: KprimaryColor,
      ),
      floatingActionButton: Builder(
        builder: (ctx){
          return FloatingActionButton(
            onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context){
                return AddTaskScreen();
              }));
            },
            child: Icon(Icons.add,color: Colors.white,),
            backgroundColor: KprimaryColor,
          );
        },
      ),
      body: StreamBuilder<List<Task>>(
        stream: TaskServices().getTasksStream(auth!.uid),
        builder: (context, snapshot) {
          if(snapshot.hasData){
            List<Task> tasks = snapshot.data!;
            if(tasks.isEmpty){
              return Center(child: Text('No Task Found'),);
            }
            else
              return ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) => TaskCard(task: tasks[index]),
              );
          }
          else{
            return Center(child: CircularProgressIndicator(color: KprimaryColor,),);
          }

        }
      ),
      drawer: CustomDrawer(name: 'name'),
    );
  }
}
